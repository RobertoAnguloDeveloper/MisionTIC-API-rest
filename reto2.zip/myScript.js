function leerClientes(){
    //FUNCION GET
        $.ajax({
            url : 'https://g54c002f2a8054d-knkzptnm2vm3gb5r.adb.sa-saopaulo-1.oraclecloudapps.com/ords/admin/client/client',
            type : 'GET',
            dataType : 'json',
            success : function(pepito) {
                console.log(pepito);
            },
            error : function(xhr, status) {
                alert('ha sucedido un problema');
            }
            
        });
}

function guardarCliente(){
    let idCliente=$("#idCliente").val();
    let nombre=$("#nombreCliente").val();
    let mailCliente=$("#mailCliente").val();
    let edad=$("#edadCliente").val();

    let data={
        id:idCliente,
        name:nombre,
        email:mailCliente,
        age:edad
    };

    let dataToSend=JSON.stringify(data);
    console.log(dataToSend);
}